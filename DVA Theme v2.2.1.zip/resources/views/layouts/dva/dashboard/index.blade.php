@extends('app')
@section('title', __('common.dashboard'))

@section('content')
@php
  // SAFE MONEY FORMATTER to avoid "Money could not be converted to float"
  if (!function_exists('format_money_any')) {
    function format_money_any($val) {
      if (is_object($val)) {
        if (method_exists($val, 'formatted'))  return $val->formatted();
        if (method_exists($val, 'format'))     return $val->format();
        if (method_exists($val, '__toString')) return (string) $val;
        if (method_exists($val, 'getAmount'))  return number_format((float) $val->getAmount(), 2);
        if (property_exists($val, 'amount'))   return number_format((float) $val->amount, 2);
        return e(json_encode($val));
      }
      return number_format((float) ($val ?? 0), 2);
    }
  }

  $balance = optional($user->journal)->balance;
  $totalFlights = (int) ($user->flights ?? 0);
  $currentAirportIcao = $current_airport ?? null;
@endphp

<div class="container-fluid px-0">

  {{-- HERO --}}
  <div class="dash-hero p-4 p-md-5 mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
      <div>
        <div class="d-flex align-items-center gap-2 mb-2">
          <span class="chip">👨‍✈️ {{ $user->name_private }}</span>
          <span class="chip">🛫 {{ $currentAirportIcao ?: '—' }}</span>
          <span class="chip">⏱️ @minutestotime($user->flight_time) {{ __('dashboard.totalhours') }}</span>
        </div>
        <h1 class="mb-1">{{ __('common.dashboard') }}</h1>
        <div class="text-muted">{{ __('Welcome back! Ready for your next leg?') }}</div>
      </div>
      {{-- Optional quick actions can go here if you want --}}
    </div>
  </div>

  @if (Auth::user()->state === \App\Models\Enums\UserState::ON_LEAVE)
    <div class="leave-alert mb-4 d-flex align-items-center gap-2">
      <span>⚠️</span>
      <div><strong>{{ __('You are on leave.') }}</strong> {{ __('File a PIREP to set your status to active!') }}</div>
    </div>
  @endif

  <div class="row g-4">
    {{-- LEFT (8 cols) --}}
    <div class="col-lg-8">
            @include('widgets.airline.totals')
        <br>
            @include('widgets/airline/last30')




 {{-- News --}}
      <div class="card-glass mt-4 mb-5">
        <div class="header-bar">📰 {{ __('Latest News') }}</div>
        <div class="p-3">
          {{ Widget::latestNews(['count' => 5]) }}
        </div>
      </div>

{{-- Recent PIREPs (kept on left) --}}
      <div class="card-glass mt-4">
        <div class="header-bar">📑 @lang('dashboard.recentreports')</div>
        <div class="p-3">
          {{ Widget::latestPireps(['count' => 5]) }}
        </div>
      </div>

      
      
    </div>

    {{-- RIGHT (4 cols) --}}
    <div class="col-lg-4">

      {{-- Weather (right side) --}}
        <div class="card-glass mt-4">
            <div class="header-bar">⛈ Weather</div>
                <div class="p-3 text-left">
              <a href="https://metar-taf.com/metar/{{ $current_airport }}" id="metartaf-beRLg6sF" style="font-size:18px; font-weight:500; color:#000; width:100%; height:278px; display:block">METAR Adolfo Suárez Madrid–Barajas Airport</a>
                <script async defer crossorigin="anonymous" src="https://metar-taf.com/embed-js/{{ $current_airport }}?u=73494&bg_color=ffffff&layout=landscape&visibility=mi&qnh=hPa&rh=rh&target=beRLg6sF"></script>
        </div>
        </div>
        
      {{-- Newest Pilots (right side) --}}
      <div class="card-glass mt-4">
        <div class="header-bar">👨‍✈️ @lang('common.newestpilots')</div>
        <div class="p-3">
          {{ Widget::latestPilots(['count' => 5]) }}
        </div>
      </div>
{{-- Last PIREP --}}
      <div class="card-glass mt-4">
        <div class="header-bar">🧾 @lang('dashboard.yourlastreport')</div>
        @if($last_pirep === null)
          <div class="p-3 text-center">
            @lang('dashboard.noreportsyet')
            <a class="fw-semibold" href="{{ route('frontend.pireps.create') }}">@lang('dashboard.fileonenow')</a>
          </div>
        @else
          @include('dashboard.pirep_card', ['pirep' => $last_pirep])
        @endif
      </div>
    </div>
  </div>
</div>
@endsection
