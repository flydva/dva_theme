@extends('app')
@section('title', trans_choice('common.pirep', 1).' '.$pirep->ident)

@section('content')
<div class="container-fluid px-0">

  {{-- HERO --}}
@php
  $unit = setting('units.distance');              // 'nm' | 'km' | 'mi'
  $distVal = optional($pirep->distance)->{$unit}; // pull the raw number from the value object
@endphp

<div class="dash-hero p-4 p-md-5 mb-4">
  <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
    <div>
      <div class="d-flex align-items-center gap-2 mb-2">
        <span class="chip">🧾 {{ __('PIREP') }}</span>
        <span class="chip">✈️ {{ $pirep->ident }}</span>
        <span class="chip">🛫 {{ $pirep->dpt_airport_id }} → 🛬 {{ $pirep->arr_airport_id }}</span>
      </div>
      <h1 class="mb-1">{{ $pirep->ident }} — {{ $pirep->dpt_airport_id }} → {{ $pirep->arr_airport_id }}</h1>
      <div class="text-muted">
        {{ optional($pirep->created_at)->toDayDateTimeString() }}
        @if(is_numeric($distVal))
          • {{ number_format($distVal) }} {{ strtoupper($unit) }}
        @endif
      </div>
    </div>

    <div class="d-flex flex-wrap gap-2">
      @if (!empty($pirep->simbrief))
        <a href="{{ route('frontend.simbrief.briefing', [$pirep->simbrief->id]) }}"
           class="btn btn-outline-primary rounded-pill">
          📄 View SimBrief
        </a>
      @endif

      @php $user = auth()->user(); @endphp
      @if(!$pirep->read_only && $user && $pirep->user_id === $user->id)
        <form method="get" action="{{ route('frontend.pireps.edit', $pirep->id) }}" class="mr-2 d-inline">
          @csrf
          <button class="btn btn-outline-info rounded-pill">@lang('common.edit')</button>
        </form>
        <form method="post" action="{{ route('frontend.pireps.submit', $pirep->id) }}" class="d-inline">
          @csrf
          <button class="btn btn-outline-success rounded-pill">@lang('common.submit')</button>
        </form>
      @endif
    </div>
  </div>
</div>


  <div class="row">
    {{-- LEFT 8 --}}
    <div class="col-lg-8">

      {{-- Departure / Arrival summary tiles --}}
      <div class="row g-4">
        <div class="col-12 col-md-6 mb-3">
          <div class="tile tile-bg-1 p-3 h-100">
            <div class="text-muted small mb-1">{{ __('Departure') }}</div>
            <div class="d-flex align-items-center justify-content-between">
              <div class="pr-2">
                <div class="font-weight-bold">
                  {{ optional($pirep->dpt_airport)->location }}
                </div>
                <div class="small">
                  <a href="{{ route('frontend.airports.show', $pirep->dpt_airport_id) }}">
                    {{ optional($pirep->dpt_airport)->full_name ?? $pirep->dpt_airport_id }}
                    ({{ $pirep->dpt_airport_id }})
                  </a>
                </div>
                @if($pirep->block_off_time)
                  <div class="small text-muted mt-1">{{ $pirep->block_off_time->toDayDateTimeString() }}</div>
                @endif
              </div>
              <div class="display-4 mb-0">🛫</div>
            </div>
          </div>
        </div>

        <div class="col-12 col-md-6 mb-3">
          <div class="tile tile-bg-2 p-3 h-100">
            <div class="text-muted small mb-1">{{ __('Arrival') }}</div>
            <div class="d-flex align-items-center justify-content-between">
              <div class="pr-2 text-right">
                <div class="font-weight-bold">
                  {{ optional($pirep->arr_airport)->location }}
                </div>
                <div class="small">
                  <a href="{{ route('frontend.airports.show', $pirep->arr_airport_id) }}">
                    {{ optional($pirep->arr_airport)->full_name ?? $pirep->arr_airport_id }}
                    ({{ $pirep->arr_airport_id }})
                  </a>
                </div>
                @if($pirep->block_on_time)
                  <div class="small text-muted mt-1">{{ $pirep->block_on_time->toDayDateTimeString() }}</div>
                @endif
              </div>
              <div class="display-4 mb-0">🛬</div>
            </div>
          </div>
        </div>
      </div>

      {{-- Progress --}}
      @if(!empty($pirep->distance))
        <div class="card-glass mb-3">
          <div class="header-bar">📍 {{ __('Progress') }}</div>
          <div class="p-3">
            <div class="progress" style="height: 10px;">
              <div class="progress-bar bg-info" role="progressbar"
                   style="width: {{ (float)$pirep->progress_percent }}%;"
                   aria-valuenow="{{ (float)$pirep->progress_percent }}"
                   aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="d-flex justify-content-between small text-muted mt-2">
              <span>{{ $pirep->dpt_airport_id }}</span>
              <span>{{ number_format((float)$pirep->progress_percent, 0) }}%</span>
              <span>{{ $pirep->arr_airport_id }}</span>
            </div>
          </div>
        </div>
      @endif

      {{-- Map --}}
      <div class="card-glass mb-4">
        <div class="header-bar">🗺️ {{ __('Route Map') }}</div>
        <div class="p-2">
          @include('pireps.map')
        </div>
      </div>

      {{-- ACARS logs --}}
      @php
        $hasLogs = is_iterable($pirep->acars_logs ?? null) && (count($pirep->acars_logs) > 0);
      @endphp
      @if($hasLogs)
        <div class="card-glass mb-4">
          <div class="header-bar">📒 @lang('pireps.flightlog')</div>
          <div class="p-0">
            <div class="table-glass">
              <div class="table-responsive">
                <table class="table table-sm table-borderless align-middle text-nowrap table-dva mb-0">
                  <tbody>
                  @foreach($pirep->acars_logs->sortBy('created_at') as $log)
                    <tr>
                      <td class="text-muted small" style="white-space:nowrap;">
                        {{ show_datetime($log->created_at) }}
                      </td>
                      <td>{{ $log->log }}</td>
                    </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      @endif

      {{-- OFP --}}
      @if(!empty($pirep->simbrief))
        <div class="card-glass mb-5">
          <div class="header-bar">📄 OFP</div>
          <div class="p-0">
            <div class="overflow-auto" style="height: 600px;">
              {!! optional($pirep->simbrief->xml->text)->plan_html !!}
            </div>
          </div>
        </div>
      @endif

    </div>

    {{-- RIGHT 4 --}}
    <div class="col-lg-4">

      {{-- Status / meta --}}
      <div class="card-glass mb-4">
        <div class="header-bar">ℹ️ {{ __('Details') }}</div>
        <div class="p-0">
          <div class="table-glass">
            <div class="table-responsive">
              <table class="table table-sm table-borderless align-middle text-nowrap table-dva mb-0">
                <tbody>
                  <tr>
                    <td class="text-muted small" style="width:38%;">@lang('common.state')</td>
                    <td>
                      <span class="badge badge-info">
                        {{ PirepState::label($pirep->state) }}
                      </span>
                    </td>
                  </tr>

                  @if ($pirep->state !== PirepState::DRAFT)
                  <tr>
                    <td class="text-muted small">@lang('common.status')</td>
                    <td>
                      <span class="badge badge-info">
                        {{ PirepStatus::label($pirep->status) }}
                      </span>
                    </td>
                  </tr>
                  @endif

                  <tr>
                    <td class="text-muted small">@lang('pireps.source')</td>
                    <td>{{ PirepSource::label($pirep->source) }}</td>
                  </tr>

                  <tr>
                    <td class="text-muted small">@lang('flights.flighttype')</td>
                    <td>{{ \App\Models\Enums\FlightType::label($pirep->flight_type) }}</td>
                  </tr>

                  @if(filled($pirep->route))
                    <tr>
                      <td class="text-muted small">@lang('pireps.filedroute')</td>
                      <td class="font-monospace">{{ $pirep->route }}</td>
                    </tr>
                  @endif

                  @if(filled($pirep->notes))
                    <tr>
                      <td class="text-muted small">{{ trans_choice('common.note', 2) }}</td>
                      <td>{{ $pirep->notes }}</td>
                    </tr>
                  @endif

                  @if($pirep->score || $pirep->landing_rate)
                    @if($pirep->score)
                      <tr>
                        <td class="text-muted small">Score</td>
                        <td>{{ number_format((float)$pirep->score) }}</td>
                      </tr>
                    @endif
                    @if($pirep->landing_rate)
                      <tr>
                        <td class="text-muted small">Landing Rate</td>
                        <td>{{ number_format((float)$pirep->landing_rate) }} fpm</td>
                      </tr>
                    @endif
                  @endif

                  <tr>
                    <td class="text-muted small">@lang('pireps.filedon')</td>
                    <td>{{ show_datetime($pirep->created_at) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {{-- Custom fields --}}
      @php
        $hasFields = is_iterable($pirep->fields ?? null) && count($pirep->fields) > 0;
      @endphp
      @if($hasFields)
        <div class="card-glass mb-4">
          <div class="header-bar">🧾 {{ trans_choice('common.field', 2) }}</div>
          <div class="p-0">
            <div class="table-glass">
              <div class="table-responsive">
                <table class="table table-sm table-borderless align-middle text-nowrap table-dva mb-0">
                  <thead>
                    <tr class="text-small header">
                      <th>@lang('common.name')</th>
                      <th>{{ trans_choice('common.value', 1) }}</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($pirep->fields as $field)
                      <tr>
                        <td class="text-muted small">{{ $field->name }}</td>
                        <td>{{ $field->value }}</td>
                      </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      @endif

      {{-- Fares --}}
      @php
        $hasFares = is_iterable($pirep->fares ?? null) && count($pirep->fares) > 0;
      @endphp
      @if($hasFares)
        <div class="card-glass mb-4">
          <div class="header-bar">💺 {{ trans_choice('pireps.fare', 2) }}</div>
          <div class="p-0">
            <div class="table-glass">
              <div class="table-responsive">
                <table class="table table-sm table-borderless align-middle text-nowrap table-dva mb-0">
                  <thead>
                    <tr class="text-small header">
                      <th>@lang('pireps.class')</th>
                      <th class="text-right">@lang('pireps.count')</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($pirep->fares as $fare)
                      <tr>
                        <td>{{ $fare->name }} ({{ $fare->code }})</td>
                        <td class="text-right">{{ $fare->count }}</td>
                      </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      @endif

    </div>
  </div>

</div>
@endsection
