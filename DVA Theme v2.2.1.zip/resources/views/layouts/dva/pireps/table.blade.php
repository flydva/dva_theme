<div class="table-glass mb-3">
  <div class="table-responsive">
    <table class="table table-hover table-striped table-dva align-middle text-nowrap mb-0">
      <thead>
        <tr class="text-small header">
          <th>@sortablelink('flight_number', trans_choice('common.flight', 1))</th>
          <th>@sortablelink('dpt_airport_id', __('common.departure'))</th>
          <th>@sortablelink('arr_airport_id', __('common.arrival'))</th>
          <th>@sortablelink('aircraft_id', __('common.aircraft'))</th>
          <th class="text-center">@sortablelink('flight_time', __('flights.flighttime'))</th>
          <th class="text-center">@sortablelink('status', __('common.status'))</th>
          <th>@sortablelink('submitted_at', __('pireps.submitted'))</th>
          <th class="text-center">✏️</th>
        </tr>
      </thead>
      <tbody>
        @foreach($pireps as $pirep)
          <tr>
            <td>
              <a href="{{ route('frontend.pireps.show', [$pirep->id]) }}" class="fw-semibold text-c">
                {{ $pirep->ident }}
              </a>
            </td>
            <td>
              @if($pirep->dpt_airport){{ $pirep->dpt_airport->name }}@endif
              (<a href="{{ route('frontend.airports.show', [$pirep->dpt_airport_id]) }}">
                {{ $pirep->dpt_airport_id }}
              </a>)
            </td>
            <td>
              @if($pirep->arr_airport){{ $pirep->arr_airport->name }}@endif
              (<a href="{{ route('frontend.airports.show', [$pirep->arr_airport_id]) }}">
                {{ $pirep->arr_airport_id }}
              </a>)
            </td>
            <td>
              {{ optional($pirep->aircraft)->ident ?? '-' }}
            </td>
            <td class="text-center">
              @minutestotime($pirep->flight_time)
            </td>
            <td class="text-center">
              @php
                $color = 'badge-info';
                if($pirep->state === PirepState::PENDING) {
                  $color = 'badge-warning';
                } elseif ($pirep->state === PirepState::ACCEPTED) {
                  $color = 'badge-success';
                } elseif ($pirep->state === PirepState::REJECTED) {
                  $color = 'badge-danger';
                }
              @endphp
              <span class="badge {{ $color }}">
                {{ PirepState::label($pirep->state) }}
              </span>
            </td>
            <td>
              @if(filled($pirep->submitted_at))
                {{ $pirep->submitted_at->diffForHumans() }}
              @endif
            </td>
            <td class="text-center">
              @if(!$pirep->read_only)
                <a href="{{ route('frontend.pireps.edit', [$pirep->id]) }}"
                   class="btn btn-sm btn-outline-info"
                   title="@lang('common.edit')">
                  ✏️
                </a>
              @endif
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
