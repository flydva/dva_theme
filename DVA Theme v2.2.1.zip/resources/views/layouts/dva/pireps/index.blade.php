@extends('app')
@section('title', trans_choice('common.pirep', 2))

@section('content')
  <div class="row">
    <div class="col-md-12">
      <div class="text-right mb-3">
  <a href="{{ route('frontend.pireps.create') }}"
     class="btn btn-dva-glass btn-lg">
    ✈️ @lang('pireps.filenewpirep')
  </a>
</div>

      <h2>{{ trans_choice('pireps.pilotreport', 2) }}</h2>
      @include('flash::message')
      @include('pireps.table')
    </div>
  </div>
  <div class="row">
    <div class="col-12 text-center">
      {{ $pireps->withQueryString()->links('pagination.default') }}
    </div>
  </div>
@endsection

