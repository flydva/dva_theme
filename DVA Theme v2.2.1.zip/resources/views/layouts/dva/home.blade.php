@extends('app')
@section('title', __('home.welcome.title'))

@section('content')
@php
  $count = is_countable($users) ? $users->count() : 0;
@endphp

<div class="container-fluid px-0">

  {{-- HERO (same look/feel as dashboard) --}}
  <div class="dash-hero p-4 p-md-5 mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
      <div>
        <h1 class="mb-1">{{ __('Welcome Aboard!') }}</h1>
        <div class="text-muted">
          {{ __('Meet our latest captains and first officers—tap a card to view a professional pilot profile.') }}
        </div>
      </div>

      {{-- Optional CTA row (link to pilots index) --}}
      <div class="d-flex flex-wrap gap-2">
        <a href="{{ route('frontend.pilots.index') }}" class="btn btn-success rounded-pill px-3">
          👀 {{ __('View All Pilots') }}
        </a>
      </div>
    </div>
  </div>
<br>
@include('layouts.dva.widgets.airline.top_pilots')


  {{-- GRID OF NEWEST PILOTS --}}
   
  <div class="card-glass mb-3">
    <div class="header-bar">👨‍✈️ @lang('common.newestpilots')</div>
    <div class="p-3">
      <div class="row">
        @forelse($users->take(4) as $user)
          <div class="col-12 col-sm-6 col-lg-4 col-xl-3 mb-3">
            <div class="card-glass h-100 p-3 d-flex flex-column">
              {{-- Avatar + Name --}}
              <div class="d-flex align-items-center mb-2">
                <div class="mr-3">
                  @if ($user->avatar)
                    <img src="{{ $user->avatar->url }}" alt="avatar"
                         style="width:64px;height:64px;border-radius:999px;object-fit:cover;border:3px solid #fff;box-shadow:0 6px 18px rgba(0,0,0,.15);">
                  @else
                    <img src="{{ $user->gravatar(256) }}" alt="avatar"
                         style="width:64px;height:64px;border-radius:999px;object-fit:cover;border:3px solid #fff;box-shadow:0 6px 18px rgba(0,0,0,.15);">
                  @endif
                </div>
                <div class="min-w-0">
                  <h5 class="mb-0 text-truncate">
                    <a href="{{ route('frontend.profile.show', [$user->id]) }}">{{ $user->name_private }}</a>
                  </h5>
                  <div class="text-muted small text-truncate">
                    {{ $user->ident }}@if(filled($user->callsign)) • {{ $user->callsign }}@endif
                  </div>
                </div>
              </div>

              {{-- Chips row (Airline / Home / Current) --}}
              <div class="d-flex flex-wrap align-items-center mb-2">
                @if(optional($user->airline)->name)
                  <span class="chip mr-2 mb-2">🏢 {{ $user->airline->name }}</span>
                @endif
                @if($user->home_airport)
                  <span class="chip mr-2 mb-2">🏠 {{ $user->home_airport->icao }}</span>
                @endif
                @if($user->current_airport)
                  <span class="chip mr-2 mb-2">🗺️ {{ $user->current_airport->icao }}</span>
                @endif
              </div>

              {{-- Mini stats tiles (inline) --}}
              <div class="row no-gutters">
                <div class="col-6 pr-1 mb-2">
                  <div class="tile tile-bg-1 p-2 text-center h-100">
                    <div class="stat-number mb-0" style="font-size:1.05rem;">{{ $user->flights }}</div>
                    <small class="text-muted">{{ trans_choice('common.flight', 2) }}</small>
                  </div>
                </div>
                <div class="col-6 pl-1 mb-2">
                  <div class="tile tile-bg-2 p-2 text-center h-100">
                    <div class="stat-number mb-0" style="font-size:1.05rem;">@minutestotime($user->flight_time)</div>
                    <small class="text-muted">@lang('flights.flighthours')</small>
                  </div>
                </div>
              </div>

              {{-- Footer action --}}
              <div class="mt-auto pt-2 d-flex">
                <a href="{{ route('frontend.profile.show', [$user->id]) }}"
                   class="btn btn-outline-primary btn-sm rounded-pill px-3 ml-auto">
                  @lang('common.profile')
                </a>
              </div>
            </div>
          </div>
        @empty
          <div class="col-12">
            <div class="text-center text-muted py-4">— {{ __('No pilots to show yet') }} —</div>
          </div>
        @endforelse
      </div>
    </div>
  </div>

</div>
@endsection
