{{-- DVA Chips Nav — Bootstrap 4.3 --}}
<div class="nav-tabs-navigation">
  <div class="nav-tabs-wrapper">

    <div class="d-flex align-items-center justify-content-between flex-wrap">

      {{-- PRIMARY (left) --}}
      <ul class="navbar-nav align-middle d-flex flex-row flex-wrap mb-0">
        @auth
          <li class="nav-item mr-2 mb-2">
            <a class="nav-link {{ request()->routeIs('frontend.dashboard.*') ? 'active' : '' }}"
               href="{{ route('frontend.dashboard.index') }}">
              <i class="fas fa-tachometer-alt"></i>
              <p class="mb-0">@lang('common.dashboard')</p>
            </a>
          </li>
        @endauth

        <li class="nav-item mr-2 mb-2">
          <a class="nav-link {{ request()->routeIs('frontend.livemap.*') ? 'active' : '' }}"
             href="{{ route('frontend.livemap.index') }}">
            <i class="fas fa-globe"></i>
            <p class="mb-0">@lang('common.livemap')</p>
          </a>
        </li>

        <li class="nav-item mr-2 mb-2">
          <a class="nav-link {{ request()->routeIs('frontend.pilots.*') ? 'active' : '' }}"
             href="{{ route('frontend.pilots.index') }}">
            <i class="fas fa-users"></i>
            <p class="mb-0">{{ trans_choice('common.pilot', 2) }}</p>
          </a>
        </li>

        {{-- Pilot Center (dropdown) --}}
        @auth
          <li class="nav-item dropdown mr-2 mb-2">
              <a class="nav-link dropdown-toggle d-inline-flex align-items-center {{ request()->routeIs('frontend.profile.*') || request()->routeIs('frontend.downloads.*') ? 'active' : '' }}"
                 href="#" id="pilotCenterMenu"
                 role="button"
                 data-toggle="dropdown"
                 data-boundary="window"
                 aria-haspopup="true"
                 aria-expanded="false">
                <i class="fas fa-user"></i>
                <p class="mb-0">Pilot Center</p>
              </a>
              <div class="dropdown-menu shadow-lg border-0" aria-labelledby="pilotCenterMenu">
                <a class="dropdown-item d-flex align-items-center" href="{{ route('frontend.profile.index') }}">
                  👤 @lang('common.profile')
                </a>
                @if(Module::find('BasicPages') && Module::find('BasicPages')->isEnabled())
                <a class="dropdown-item" href="{{ route('basicpages.weather') }}">
                  ⛅ Live Weather
                </a>
                @endif
                <a class="dropdown-item d-flex align-items-center" href="{{ route('frontend.downloads.index') }}">
                  <i class="fas fa-download mr-2"></i> {{ trans_choice('common.download', 2) }}
                </a>
              </div>
            </li>

        {{-- Airline --}}
            <li class="nav-item dropdown mr-2 mb-2">
              <a class="nav-link dropdown-toggle d-inline-flex align-items-center 
                 {{ request()->routeIs('frontend.profile.*') || request()->routeIs('frontend.downloads.*') ? 'active' : '' }}"
                 href="#" id="pilotCenterMenu"
                 role="button"
                 data-toggle="dropdown"
                 data-boundary="window"
                 aria-haspopup="true"
                 aria-expanded="false">
                <i class="fas fa-plane"></i>
                <p class="mb-0">{{ config('app.name') }}</p>
              </a>
              <div class="dropdown-menu shadow-lg border-0" aria-labelledby="pilotCenterMenu">
                <a class="dropdown-item d-flex align-items-center" href="{{ route('frontend.flights.index') }}">
                  ✈️ Flights
                </a>
                <a class="dropdown-item d-flex align-items-center" href="{{ route('frontend.pireps.index') }}">
                  <i class="fas fa-file mr-2"></i> PIREPS
                </a>
            
                {{-- Show Hubs if DVAHubs module is installed --}}
                @if(check_module('DVAHubs'))
                  <a class="dropdown-item d-flex align-items-center" href="{{ url('dvahubs') }}">
                    <i class="fas fa-building mr-2"></i> Hubs
                  </a>
                @endif
                @if(check_module('Fleet'))
                  <a class="dropdown-item d-flex align-items-center" href="{{ url('fleet') }}">
                    <i class="fas fa-plane mr-2"></i> Fleet
                  </a>
                @endif
              </div>
            </li>
        @endauth

        {{-- Public module links (guest-visible) --}}
        @foreach($moduleSvc->getFrontendLinks($logged_in=false) as $link)
          <li class="nav-item mr-2 mb-2">
            <a class="nav-link {{ url()->current() === url($link['url']) ? 'active' : '' }}"
               href="{{ url($link['url']) }}">
              <i class="{{ $link['icon'] }}"></i>
              <p class="mb-0">{{ $link['title'] }}</p>
            </a>
          </li>
        @endforeach

        {{-- Static pages --}}
        @foreach($page_links as $page)
          <li class="nav-item mr-2 mb-2">
            <a class="nav-link"
               href="{{ $page->url }}"
               target="{{ $page->new_window ? '_blank' : '_self' }}">
              <i class="{{ $page['icon'] }}"></i>
              <p class="mb-0">{{ $page['name'] }}</p>
            </a>
          </li>
        @endforeach

        @auth

          {{-- Auth module links --}}
          @foreach($moduleSvc->getFrontendLinks($logged_in=true) as $link)
            <li class="nav-item mr-2 mb-2">
              <a class="nav-link {{ url()->current() === url($link['url']) ? 'active' : '' }}"
                 href="{{ url($link['url']) }}">
                <i class="{{ $link['icon'] }}"></i>
                <p class="mb-0">{{ $link['title'] }}</p>
              </a>
            </li>
          @endforeach
        @endauth
      </ul>

      {{-- UTILITY (right): language + auth --}}
      <ul class="navbar-nav align-middle d-flex flex-row flex-wrap mb-0">

        {{-- Language (BS4 dropdown) --}}
        <li class="nav-item dropdown position-static mr-2 mb-2">
          <a class="nav-link dropdown-toggle d-inline-flex align-items-center"
             href="#" id="langMenu" role="button"
             data-toggle="dropdown" data-boundary="window"
             aria-haspopup="true" aria-expanded="false">
            <span class="flag-icon flag-icon-{{ $languages[$locale]['flag-icon'] }}"></span>&nbsp;
            <span class="mb-0">{{ $languages[$locale]['display'] }}</span>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="langMenu">
            @foreach ($languages as $lang => $language)
              @if ($lang != $locale)
                <a class="dropdown-item d-flex align-items-center"
                   href="{{ route('frontend.lang.switch', $lang) }}">
                  <span class="flag-icon flag-icon-{{ $language['flag-icon'] }}"></span>&nbsp;{{ $language['display'] }}
                </a>
              @endif
            @endforeach
          </div>
        </li>

        @guest
          <li class="nav-item mr-2 mb-2">
            <a class="nav-link" href="{{ url('/register') }}">
              <i class="far fa-id-card"></i>
              <p class="mb-0">@lang('common.register')</p>
            </a>
          </li>
          <li class="nav-item mr-2 mb-2">
            <a class="nav-link" href="{{ url('/login') }}">
              <i class="fas fa-sign-in-alt"></i>
              <p class="mb-0">@lang('common.login')</p>
            </a>
          </li>
        @endguest

        @auth
          {{-- User (Bootstrap 4.3 dropdown) --}}
          <li class="nav-item dropdown position-static mb-2">
            <a class="nav-link dropdown-toggle p-0 d-flex align-items-center"
               href="#" id="userMenu"
               role="button"
               data-toggle="dropdown"
               data-boundary="window"
               aria-haspopup="true"
               aria-expanded="false">
              @if (Auth::user()->avatar == null)
                <img src="{{ Auth::user()->gravatar(38) }}"
                     alt="avatar"
                     class="rounded-circle"
                     style="height:38px;width:38px;object-fit:cover;">
              @else
                <img src="{{ Auth::user()->avatar->url }}"
                     alt="avatar"
                     class="rounded-circle"
                     style="height:38px;width:38px;object-fit:cover;">
              @endif
            </a>

            <div class="dropdown-menu dropdown-menu-right shadow-lg border-0" aria-labelledby="userMenu">
              
              @if(Module::find('BasicPages') && Module::find('BasicPages')->isEnabled())
                <a class="dropdown-item" href="{{ route('basicpages.policies') }}">
                  📜 Policies
                </a>
                <a class="dropdown-item" href="{{ route('basicpages.terms') }}">
                  📝 Terms & Conditions
                </a>
              @endif

              @ability('admin', 'admin-access')
                <a class="dropdown-item" href="{{ url('/admin') }}">
                  <i class="fas fa-circle-notch"></i>&nbsp;&nbsp;@lang('common.administration')
                </a>
              @endability

              <div class="dropdown-divider"></div>

              <a class="dropdown-item text-danger" href="{{ url('/logout') }}">
                <i class="fas fa-sign-out-alt"></i>&nbsp;&nbsp;@lang('common.logout')
              </a>
            </div>
          </li>
        @endauth
      </ul>
    </div>
  </div>
</div>
