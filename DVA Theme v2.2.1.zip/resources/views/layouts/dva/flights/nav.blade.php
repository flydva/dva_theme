<div class="text-right">
  <div class="form-group text-right">
    <a href="{{ route('frontend.flights.bids') }}"
       class="btn btn-outline-primary">{{ trans_choice('flights.mybid', 2) }}</a>
  </div>
</div>
