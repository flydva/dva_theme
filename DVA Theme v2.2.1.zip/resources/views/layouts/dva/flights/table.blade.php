<div class="table-responsive">
  <table class="table table-sm table-borderless align-middle text-nowrap table-dva mb-0">
    <thead>
      <tr>
        <th>@sortablelink('airline_id', __('common.airline'))</th>
        <th>@sortablelink('flight_number', __('flights.flightnumber'))</th>
        <th>@sortablelink('dpt_airport_id', __('airports.departure'))</th>
        <th>@sortablelink('arr_airport_id', __('airports.arrival'))</th>
        <th>@sortablelink('dpt_time', 'STD')</th>
        <th>@sortablelink('arr_time', 'STA')</th>
        <th>@sortablelink('distance', 'Distance')</th>
        <th>@sortablelink('flight_time', 'Flight Time')</th>
        <th class="text-right">File Pirep</th>
        <th class="text-right">Place Bid</th>
      </tr>
    </thead>
    <tbody>
      @foreach($flights as $flight)
        <tr>
          {{-- Airline logo / ICAO --}}
          <td class="align-middle text-center">
            @if(optional($flight->airline)->logo)
              <img src="{{ $flight->airline->logo }}"
                   alt="{{ $flight->airline->name }}"
                   style="max-height:30px;" class="mr-2">
            @endif
            {{ $flight->airline->icao ?? '' }}
          </td>

          {{-- Flight ident --}}
          <td class="align-middle">
            <a href="{{ route('frontend.flights.show', [$flight->id]) }}">
              <strong>{{ $flight->ident }}</strong>
            </a>
            @if(filled($flight->callsign) && !setting('simbrief.callsign', true))
              <span class="text-muted">| {{ $flight->atc }}</span>
            @endif
          </td>

          {{-- Departure --}}
          <td class="align-middle">
            <a href="{{ route('frontend.airports.show', ['id' => $flight->dpt_airport_id]) }}">
              {{ $flight->dpt_airport_id }}
            </a>
            @if($flight->dpt_time) <small>({{ $flight->dpt_time }})</small>@endif
          </td>

          {{-- Arrival --}}
          <td class="align-middle">
            <a href="{{ route('frontend.airports.show', ['id' => $flight->arr_airport_id]) }}">
              {{ $flight->arr_airport_id }}
            </a>
            @if($flight->arr_time) <small>({{ $flight->arr_time }})</small>@endif
          </td>

          {{-- STD / STA --}}
          <td class="align-middle">{{ $flight->dpt_time ?? '—' }}</td>
          <td class="align-middle">{{ $flight->arr_time ?? '—' }}</td>

          {{-- Distance --}}
          <td class="align-middle">
            {{ $flight->distance ? $flight->distance.' '.setting('units.distance') : '—' }}
          </td>

          {{-- Flight time --}}
          <td class="align-middle">{{ $flight->flight_time ?? '—' }}</td>

          {{-- Actions --}}
          <td class="align-middle text-right">
            <a href="{{ route('frontend.pireps.create') }}?flight_id={{ $flight->id }}"
               class="btn btn-sm btn-outline-info">
              {{ __('pireps.newpirep') }}
            </a>
          </td>
          <td class="align-middle text-center">
  @if (!setting('pilots.only_flights_from_current') || $flight->dpt_airport_id == $user->current_airport->icao)
    <button class="btn btn-round btn-icon btn-icon-mini save_flight {{ isset($saved[$flight->id]) ? 'btn-info' : '' }}"
            x-id="{{ $flight->id }}" 
            x-saved-class="btn-info"
            type="button" 
            title="@lang('flights.addremovebid')">
      <i class="fas fa-map-marker"></i>
    </button>
  @endif
</td>

        </tr>
      @endforeach
    </tbody>
  </table>
</div>
