

<div class="card-glass p-4 search-form">
    <h4 class="description mb-3">✈️ @lang('flights.search')</h4>
  <form method="get" action="{{ route('frontend.flights.search') }}">
    @csrf

    {{-- Airline --}}
    <div class="form-group mb-3">
      <label for="airline_id" class="form-label">@lang('common.airline')</label>
      <select name="airline_id" id="airline_id" class="form-control select2">
        @foreach($airlines as $airline_id => $airline_label)
          <option value="{{ $airline_id }}" @if(request()->get('airline_id') == $airline_id) selected @endif>
            {{ $airline_label }}
          </option>
        @endforeach
      </select>
    </div>

    {{-- Flight Type --}}
    <div class="form-group mb-3">
      <label for="flight_type" class="form-label">@lang('flights.flighttype')</label>
      <select name="flight_type" id="flight_type" class="form-control select2">
        @foreach($flight_types as $flight_type_id => $flight_type_label)
          <option value="{{ $flight_type_id }}" @if(request()->get('flight_type') == $flight_type_id) selected @endif>
            {{ $flight_type_label }}
          </option>
        @endforeach
      </select>
    </div>

    {{-- Flight Number --}}
    <div class="form-group mb-3">
      <label for="flight_number" class="form-label">@lang('flights.flightnumber')</label>
      <input type="text" name="flight_number" id="flight_number"
             value="{{ request()->get('flight_number') }}"
             class="form-control"/>
    </div>

    {{-- Route Code --}}
    <div class="form-group mb-3">
      <label for="route_code" class="form-label">@lang('flights.code')</label>
      <input type="text" name="route_code" id="route_code"
             value="{{ request()->get('route_code') }}"
             class="form-control"/>
    </div>

    {{-- Departure --}}
    <div class="form-group mb-3">
      <label for="dep_icao" class="form-label">@lang('airports.departure')</label>
      <select name="dep_icao" id="dep_icao" class="form-control airport_search"></select>
    </div>

    {{-- Arrival --}}
    <div class="form-group mb-3">
      <label for="arr_icao" class="form-label">@lang('airports.arrival')</label>
      <select name="arr_icao" id="arr_icao" class="form-control airport_search"></select>
    </div>

    {{-- Subfleet --}}
    <div class="form-group mb-3">
      <label for="subfleet_id" class="form-label">@lang('common.subfleet')</label>
      <select name="subfleet_id" id="subfleet_id" class="form-control select2">
        @foreach($subfleets as $subfleet_id => $subfleet_label)
          <option value="{{ $subfleet_id }}" @if(request()->get('subfleet_id') == $subfleet_id) selected @endif>
            {{ $subfleet_label }}
          </option>
        @endforeach
      </select>
    </div>

    {{-- Type Rating (optional) --}}
    @if(filled($type_ratings))
      <div class="form-group mb-3">
        <label for="type_rating_id" class="form-label">Type Rating</label>
        <select name="type_rating_id" id="type_rating_id" class="form-control select2">
          <option value=""></option>
          @foreach($type_ratings as $tr)
            <option value="{{ $tr->id }}" @if(request()->get('type_rating_id') == $tr->id) selected @endif>
              {{ $tr->type.' | '.$tr->name }}
            </option>
          @endforeach
        </select>
      </div>
    @endif

    {{-- ICAO Type (optional) --}}
    @if(filled($icao_codes))
      <div class="form-group mb-3">
        <label for="icao_type" class="form-label">ICAO Type</label>
        <select name="icao_type" id="icao_type" class="form-control select2">
          <option value=""></option>
          @foreach($icao_codes as $icao)
            <option value="{{ $icao }}" @if(request()->get('icao_type') == $icao) selected @endif>
              {{ $icao }}
            </option>
          @endforeach
        </select>
      </div>
    @endif

    {{-- Actions --}}
    <div class="d-flex align-items-center gap-3 mt-4">
      <button type="submit" class="btn btn-primary px-4">
        🔎 @lang('common.find')
      </button>
      <a href="{{ route('frontend.flights.index') }}" class="btn btn-link text-muted">
        @lang('common.reset')
      </a>
    </div>

  </form>
</div>
