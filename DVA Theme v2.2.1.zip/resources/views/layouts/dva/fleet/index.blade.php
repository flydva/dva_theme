@extends('app')
@section('title', __('Fleet'))

@section('content')
<div class="dash-hero p-4 mb-4">
  <h1 class="mb-0">✈️ Fleet</h1>
  <div class="text-muted">Explore our aircraft and liveries</div>
</div>

<div class="card-glass p-3">
  <p>This is your fleet page. You can add tables, cards, or widgets here.</p>
</div>
@endsection
