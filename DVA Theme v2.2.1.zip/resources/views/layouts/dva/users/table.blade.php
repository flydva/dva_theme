@extends('app')
@section('title', __('common.pilot').' '.__('common.list'))

@section('content')
<div class="container-fluid px-0">

  {{-- Page Hero --}}
  <div class="dash-hero p-4 p-md-5 mb-4">
    <div class="d-flex flex-wrap align-items-end justify-content-between gap-3">
      <div>
        <h1 class="mb-1">👨‍✈️ Pilots</h1>
        <div class="text-muted">{{ __('Browse all active pilots in the airline') }}</div>
      </div>

      {{-- Search Bar (GET keeps query params for pagination/sort/per-page) --}}
      <form method="GET" action="{{ url()->current() }}" class="w-100 w-md-auto" role="search">
        {{-- Preserve other query params except q/page --}}
        @foreach(request()->except('q', 'page') as $k => $v)
          <input type="hidden" name="{{ $k }}" value="{{ $v }}">
        @endforeach

        <div class="input-group input-group-sm" style="min-width: 260px;">
          <input
            type="text"
            name="q"
            class="form-control"
            placeholder="{{ __('Search by name, ident or airport…') }}"
            value="{{ request('q', '') }}"
            aria-label="{{ __('Search') }}">
          <div class="input-group-append">
            <button class="btn btn-primary" type="submit">
              <i class="fas fa-search"></i> <span class="d-none d-sm-inline">{{ __('Search') }}</span>
            </button>
            @if(request()->filled('q'))
              <a class="btn btn-outline-secondary" href="{{ url()->current() }}" title="{{ __('Clear') }}">
                <i class="fas fa-times"></i>
              </a>
            @endif
          </div>
        </div>
      </form>
    </div>
  </div>

  {{-- Table Card --}}
  <div class="table-glass">
    <div class="header-bar d-flex align-items-center justify-content-between">
      <span>✈️ Active Pilots</span>

      {{-- Small meta (results count) --}}
      <small class="text-muted">
        @php
          $from = ($users->currentPage() - 1) * $users->perPage() + 1;
          $to   = min($users->total(), $users->currentPage() * $users->perPage());
        @endphp
        {{ __('Showing') }} {{ $users->total() ? $from : 0 }}–{{ $users->total() ? $to : 0 }} {{ __('of') }} {{ $users->total() }}
      </small>
    </div>

    <div class="table-responsive">
      <table class="table table-hover table-striped table-dva mb-0" id="users-table">
        <thead>
          <tr class="text-small header">
            <th style="width:80px;"></th>
            <th>@sortablelink('name', __('common.name'))</th>
            <th class="text-center"></th>
            <th class="text-center">@sortablelink('airline_id', __('common.airline'))</th>
            <th class="text-center">@sortablelink('curr_airport_id', __('user.location'))</th>
            <th class="text-center">@sortablelink('flights', trans_choice('common.flight', 2))</th>
            <th class="text-center">@sortablelink('flight_time', trans_choice('common.hour', 2))</th>
          </tr>
        </thead>

        <tbody>
          @forelse($users as $user)
            <tr>
              <td>
                <div class="photo-container">
                  @if ($user->avatar == null)
                    <img class="rounded-circle"
                         src="{{ $user->gravatar(256) }}&s=256"
                         alt="avatar"
                         style="height:48px;width:48px;object-fit:cover;">
                  @else
                    <img class="rounded-circle"
                         src="{{ $user->avatar->url }}"
                         alt="avatar"
                         style="height:48px;width:48px;object-fit:cover;">
                  @endif
                </div>
              </td>

              <td data-label="{{ __('common.name') }}">
                <a href="{{ route('frontend.users.show.public', [$user->id]) }}">
                  {{$user->ident}}&nbsp;{{ $user->name_private }}
                </a>
              </td>

              <td class="text-center" data-label="">
                @if(filled($user->country))
                  <span class="flag-icon flag-icon-{{ $user->country }}"
                        title="{{ $country->alpha2($user->country)['name'] }}"></span>
                @endif
              </td>

              <td class="text-center" data-label="@lang('common.airline')">
                {{ optional($user->airline)->icao }}
              </td>

              <td class="text-center" data-label="@lang('user.location')">
                {{ $user->current_airport ? $user->curr_airport_id : '–' }}
              </td>

              <td class="text-center" data-label="{{ trans_choice('common.flight', 2) }}">
                {{ $user->flights }}
              </td>

              <td class="text-center" data-label="{{ trans_choice('common.hour', 2) }}">
                @minutestotime($user->flight_time)
              </td>
            </tr>
          @empty
            <tr>
              <td colspan="7" class="text-center py-5">
                <div class="text-muted">{{ __('No pilots found for this search.') }}</div>
              </td>
            </tr>
          @endforelse
        </tbody>
      </table>
    </div>

    {{-- Footer: Per-page + Pagination --}}
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 p-3 border-top">

      {{-- Per-page selector (auto-submits, preserves query) --}}
      <form method="GET" action="{{ url()->current() }}" class="form-inline">
        @foreach(request()->except('per_page', 'page') as $k => $v)
          <input type="hidden" name="{{ $k }}" value="{{ $v }}">
        @endforeach

        @php
          $currentPerPage = (int) (request('per_page', $users->perPage()) ?: 25);
          $perPageOptions = [10, 25, 50, 100];
          if (!in_array($currentPerPage, $perPageOptions)) { $perPageOptions[] = $currentPerPage; sort($perPageOptions); }
        @endphp

        <label for="perPage" class="mr-2 mb-0 text-muted">{{ __('Rows per page') }}</label>
        <select id="perPage" name="per_page" class="custom-select custom-select-sm mr-2"
                onchange="this.form.submit()">
          @foreach($perPageOptions as $opt)
            <option value="{{ $opt }}" {{ $currentPerPage == $opt ? 'selected' : '' }}>
              {{ $opt }}
            </option>
          @endforeach
        </select>

        <noscript><button type="submit" class="btn btn-sm btn-outline-secondary">{{ __('Apply') }}</button></noscript>
      </form>

      <small class="text-muted mb-0 order-3 order-md-2">
        {{ __('Page') }} {{ $users->currentPage() }} {{ __('of') }} {{ $users->lastPage() }}
      </small>

      <div class="mb-0 order-2 order-md-3">
        {{-- Keep current query (search/sort/per-page) in pagination links --}}
        {{ $users->appends(request()->query())->links('pagination::bootstrap-4') }}
      </div>
    </div>
  </div>

</div>
@endsection
