@extends('auth.login_layout')
{{-- FORCE BODY CLASS + OVERRIDES --}}
@section('body_class', 'login-page')
@push('styles')
<style>
  /* 1) Hard-reset any earlier background rules */
  html, body { background: none !important; }
  /* 2) Force the image as the body background */
  body.login-page{
    background: url("{{ asset('dva/a339.png') }}") center center / cover fixed no-repeat !important;
  }
  /* 3) Kill any global overlays that tint the whole site */
  body.login-page::before,
  body.login-page::after{
    content: none !important;
    display: none !important;
  }
  /* 4) Make sure page content appears above anything leftover */
  body.login-page > *{ position: relative; z-index: 1; }
</style>
@endpush

@section('title', __('common.login'))

@section('content')
@section('body_class', 'login-page')
<style>
  html, body { background: none !important; }
  body.login-page{
    background: url("{{ asset('dva/a339.png') }}") center center / cover fixed no-repeat !important;
  }
  body.login-page::before,
  body.login-page::after{ content: none !important; display: none !important; }
  body.login-page > *{ position: relative; z-index: 1; }
</style>

<body class="login-page">
  <div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="card-glass p-4 p-md-5" style="max-width:420px; width:100%;">
      
      {{-- Logo --}}
      <div class="text-center mb-4">
        <img src="{{ public_asset('/dva/dva-logo.png') }}" 
             alt="Logo" 
             class="img-fluid" 
             style="width: 180px; background:#fff; border-radius:12px; padding:8px; box-shadow:0 6px 18px rgba(0,0,0,.1);">
      </div>

      {{-- Login Form --}}
      <form method="post" action="{{ url('/login') }}" class="form">
        @csrf

        <div class="form-group mb-3">
          <label for="email" class="form-label fw-semibold">@lang('common.email') / @lang('common.pilot_id')</label>
          <input type="text" 
                 name="email" 
                 id="email" 
                 class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" 
                 value="{{ old('email') }}" 
                 required autofocus>
          @if ($errors->has('email'))
            <div class="invalid-feedback">{{ $errors->first('email') }}</div>
          @endif
        </div>

        <div class="form-group mb-3">
          <label for="password" class="form-label fw-semibold">@lang('auth.password')</label>
          <input type="password" 
                 name="password" 
                 id="password" 
                 class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" 
                 required>
          @if ($errors->has('password'))
            <div class="invalid-feedback">{{ $errors->first('password') }}</div>
          @endif
        </div>

        <button class="btn btn-primary btn-lg w-100 mb-3">@lang('common.login')</button>

        {{-- OAuth Providers --}}
        @if(config('services.discord.enabled'))
          <a href="{{ route('oauth.redirect', ['provider' => 'discord']) }}" class="btn btn-lg w-100 mb-2" style="background-color:#738ADB; color:#fff;">
            <i class="fab fa-discord"></i> @lang('auth.loginwith', ['provider' => 'Discord'])
          </a>
        @endif
        @if(config('services.ivao.enabled'))
          <a href="{{ route('oauth.redirect', ['provider' => 'ivao']) }}" class="btn btn-lg w-100 mb-2" style="background-color:#0d2c99; color:#fff;">
            <i class="fas fa-plane-departure"></i> @lang('auth.loginwith', ['provider' => 'IVAO'])
          </a>
        @endif
        @if(config('services.vatsim.enabled'))
          <a href="{{ route('oauth.redirect', ['provider' => 'vatsim']) }}" class="btn btn-lg w-100 mb-2" style="background-color:#29B473; color:#fff;">
            <i class="fas fa-broadcast-tower"></i> @lang('auth.loginwith', ['provider' => 'VATSIM'])
          </a>
        @endif

        <div class="d-flex justify-content-between mt-3">
          <a href="{{ url('/register') }}" class="small">@lang('auth.createaccount')</a>
          <a href="{{ url('/password/reset') }}" class="small">@lang('auth.forgotpassword')?</a>
        </div>
      </form>
    </div>
  </div>
</body>
@endsection
