<div>
  <p style="float:left; margin-right: 10px; margin-left: 2px;">
        <span style="font-size: 1.0em;">
            <i class="fas fa-info-circle" style="color: #067ec1"></i>
        </span>
  </p>
  <p>
    {{ $slot }}
  </p>
</div>
