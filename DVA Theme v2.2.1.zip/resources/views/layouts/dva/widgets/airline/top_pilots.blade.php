@php
  use App\Models\Pirep;
  use App\Models\User;
  use Illuminate\Support\Facades\DB;

  $period = request('period', '30d');

  $from = match ($period) {
      '7d'   => now()->subDays(7),
      '30d'  => now()->subDays(30),
      '90d'  => now()->subDays(90),
      'all'  => now()->startOfDay()->subYears(100),
      default => now()->subDays(30),
  };

  $rows = Pirep::query()
      ->where('created_at', '>=', $from)
      ->select([
          'user_id',
          DB::raw('SUM(flight_time) as minutes'),
          DB::raw('SUM(distance) as distance_nm'),
          DB::raw('AVG(landing_rate) as avg_landing_fpm'),
          DB::raw('COUNT(*) as flights'),
          // use the raw pirep score as the leaderboard score
          DB::raw('COALESCE(SUM(score), 0) as pirep_score'),
      ])
      ->groupBy('user_id')
      ->orderByDesc('pirep_score')
      ->limit(200)
      ->get()
      ->keyBy('user_id');

  $users = User::query()
      ->whereIn('id', $rows->keys())
      ->select('id','name','pilot_id')
      ->get()
      ->keyBy('id');

  $leaders = $rows->map(function($r,$uid) use ($users) {
      $hours   = round(($r->minutes ?? 0) / 60, 1);
      $dist    = (int) round($r->distance_nm ?? 0);
      $flts    = (int) ($r->flights ?? 0);
      $avgLd   = $r->avg_landing_fpm !== null ? round($r->avg_landing_fpm) : null;

      return (object)[
          'user'            => $users->get($uid),
          'hours'           => $hours,
          'distance_nm'     => $dist,
          'flights'         => $flts,
          'avg_landing_fpm' => $avgLd,
          // leaderboard score = sum of PIREP scores
          'score'           => (float) $r->pirep_score,
      ];
  })->sortByDesc('score')->take(10)->values();
@endphp

<div class="card card-glass shadow-sm border-0 h-100">
  <div class="card-header bg-transparent d-flex align-items-center justify-content-between">
    <h5 class="mb-0">🏅 Top Pilots</h5>
    <div class="btn-group btn-group-sm">
      @foreach(['7d'=>'7d','30d'=>'30d','90d'=>'90d','all'=>'All'] as $k=>$lbl)
        <a href="{{ request()->fullUrlWithQuery(['period'=>$k]) }}"
           class="btn {{ $period === $k ? 'btn-success' : 'btn-outline-success' }}">
          {{ $lbl }}
        </a>
      @endforeach
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-sm mb-0">
        <thead>
          <tr>
            <th>#</th>
            <th>Pilot</th>
            <th class="text-end">Hours</th>
            <th class="text-end">Distance</th>
            <th class="text-end">Flights</th>
            <th class="text-end">Avg Ldg</th>
            <th class="text-end">Score</th>
          </tr>
        </thead>
        <tbody>
        @forelse($leaders as $i=>$row)
          <tr>
            <td>{{ $i+1 }}</td>
            <td>
              @if($row->user)
                <span class="badge bg-gradient-primary">{{ $row->user->pilot_id }}</span>
                {{ $row->user->name }}
              @else
                Unknown
              @endif
            </td>
            <td class="text-end">{{ $row->hours }}</td>
            <td class="text-end">{{ number_format($row->distance_nm) }}</td>
            <td class="text-end">{{ number_format($row->flights) }}</td>
            <td class="text-end">{{ $row->avg_landing_fpm ?? '—' }}</td>
            <td class="text-end fw-bold">{{ number_format($row->score, 0) }}</td>
          </tr>
        @empty
          <tr><td colspan="7" class="text-center text-muted py-4">No data available.</td></tr>
        @endforelse
        </tbody>
      </table>
    </div>
  </div>
</div>
