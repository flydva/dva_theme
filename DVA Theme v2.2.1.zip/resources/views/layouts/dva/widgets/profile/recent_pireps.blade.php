{{-- resources/views/widgets/profile/recent_pireps.blade.php --}}
@php
use App\Models\Pirep;
use App\Models\Enums\PirepState;

/** @var \App\Models\User $user */
$limit = $limit ?? 5;
$rows = Pirep::with(['dpt_airport','arr_airport','aircraft'])
  ->where('user_id', $user->id)
  ->orderByDesc('submitted_at')
  ->limit($limit)
  ->get();
@endphp

<div class="card-glass">
  <div class="header-bar">🧾 {{ __('Recent PIREPs') }}</div>
  <div class="p-3">
    @if($rows->isEmpty())
      <div class="text-center text-muted py-3">— {{ __('No reports yet') }} —</div>
    @else
      <div class="table-responsive">
        <table class="table table-sm table-borderless align-middle table-dva mb-0">
          <thead>
            <tr class="text-small header">
              <th>{{ __('Flight') }}</th>
              <th>{{ __('Departure') }}</th>
              <th>{{ __('Arrival') }}</th>
              <th class="text-center">{{ __('Time') }}</th>
              <th class="text-center">{{ __('Status') }}</th>
              <th class="text-right"></th>
            </tr>
          </thead>
          <tbody>
          @foreach($rows as $p)
            @php
              $color = 'badge-info';
              if($p->state === PirepState::PENDING)   $color = 'badge-warning';
              elseif($p->state === PirepState::ACCEPTED) $color = 'badge-success';
              elseif($p->state === PirepState::REJECTED) $color = 'badge-danger';
            @endphp
            <tr>
              <td><a href="{{ route('frontend.pireps.show', [$p->id]) }}">{{ $p->ident }}</a></td>
              <td>{{ optional($p->dpt_airport)->icao ?? $p->dpt_airport_id }}</td>
              <td>{{ optional($p->arr_airport)->icao ?? $p->arr_airport_id }}</td>
              <td class="text-center">@minutestotime($p->flight_time)</td>
              <td class="text-center">
                <span class="badge {{ $color }}">{{ \App\Models\Enums\PirepState::label($p->state) }}</span>
              </td>
              <td class="text-right">
                <a href="{{ route('frontend.pireps.show', [$p->id]) }}" class="btn btn-xs btn-outline-primary rounded-pill px-2">
                  {{ __('View') }}
                </a>
              </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      </div>
    @endif
  </div>
</div>
