@extends('app')
@section('title', __('common.profile'))

@section('content')
@php
  $countryCode   = $user->country;
  $rank          = optional($user->rank);
  $airline       = optional($user->airline);
  $homeIcao      = optional($user->home_airport)->icao;
  $currIcao      = optional($user->current_airport)->icao;
@endphp

<div class="container-fluid px-0">

  {{-- HERO — matches dashboard --}}
  <div class="dash-hero p-4 p-md-5 mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between">
      <div class="d-flex align-items-center">
        <div class="mr-3">
          @if ($user->avatar)
            <img src="{{ $user->avatar->url }}" alt="avatar"
                 style="width:96px;height:96px;border-radius:999px;object-fit:cover;border:4px solid #fff;box-shadow:0 10px 24px rgba(0,0,0,.18);">
          @else
            <img src="{{ $user->gravatar(512) }}" alt="avatar"
                 style="width:96px;height:96px;border-radius:999px;object-fit:cover;border:4px solid #fff;box-shadow:0 10px 24px rgba(0,0,0,.18);">
          @endif
        </div>
        <div>
          <div class="d-flex flex-wrap align-items-center mb-2">
            <span class="chip mr-2 mb-2">👨‍✈️ {{ $user->name_private }}</span>
            <span class="chip mr-2 mb-2">🆔 {{ $user->ident }}@if(filled($user->callsign)) • {{ $user->callsign }}@endif</span>
            @if($countryCode)
              <span class="chip mr-2 mb-2"><span class="flag-icon flag-icon-{{ $countryCode }}"></span>&nbsp;{{ $countryCode }}</span>
            @endif
            
          </div>
          <h1 class="mb-1">{{ $airline->name ?? __('common.profile') }}</h1>
        </div>
      </div>

      {{-- Primary actions (only when owner) --}}
      @if(Auth::check() && $user->id === Auth::user()->id)
        <div class="d-flex flex-wrap justify-content-end">
          <a href="{{ route('frontend.profile.edit', [$user->id]) }}" class="btn btn-dva-primary mr-2 mb-2">@lang('common.edit')</a>
          @if (isset($acars) && $acars === true)
            <a href="{{ route('frontend.profile.acars') }}" class="btn btn-dva-secondary mr-2 mb-2"
               onclick="alert('Copy or Save to \"My Documents/vmsacars/profiles\"')">ACARS Config</a>
          @endif
          @if(config('services.discord.enabled'))
            @if(!$user->discord_id)
              <a href="{{ route('oauth.redirect', ['provider' => 'discord']) }}" class="btn btn-dva-secondary mr-2 mb-2">Link Discord</a>
            @else
              <a href="{{ route('oauth.logout', ['provider' => 'discord']) }}" class="btn btn-dva-secondary mr-2 mb-2">Unlink Discord</a>
            @endif
          @endif
          @if(config('services.vatsim.enabled'))
            @if(!$user->vatsim_id)
              <a href="{{ route('oauth.redirect', ['provider' => 'vatsim']) }}" class="btn btn-dva-secondary mr-2 mb-2">Link VATSIM</a>
            @else
              <a href="{{ route('oauth.logout', ['provider' => 'vatsim']) }}" class="btn btn-dva-secondary mr-2 mb-2">Unlink VATSIM</a>
            @endif
          @endif
          @if(config('services.ivao.enabled'))
            @if(!$user->ivao_id)
              <a href="{{ route('oauth.redirect', ['provider' => 'ivao']) }}" class="btn btn-dva-secondary mr-2 mb-2">Link IVAO</a>
            @else
              <a href="{{ route('oauth.logout', ['provider' => 'ivao']) }}" class="btn btn-dva-secondary mr-2 mb-2">Unlink IVAO</a>
            @endif
          @endif
        </div>
      @endif
    </div>
  </div>

  <div class="row">
    {{-- LEFT (8) --}}
    <div class="col-lg-8">

      {{-- 2×2 STAT TILES (dashboard tiles) --}}
      <div class="row">
        <div class="col-md-6 mb-3">
          <div class="tile tile-bg-1 text-center h-100 p-3">
            <h2 class="stat-number mb-0">{{ $user->flights }}</h2>
            <small class="d-block text-muted">{{ __('Flights') }}</small>
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <div class="tile tile-bg-2 text-center h-100 p-3">
            <h2 class="stat-number mb-0">@minutestotime($user->flight_time)</h2>
            <small class="d-block text-muted">@lang('flights.flighthours')</small>
          </div>
        </div>
        @if($currIcao)
        <div class="col-md-6 mb-3">
          <div class="tile tile-bg-3 text-center h-100 p-3">
            <h2 class="stat-number mb-0">{{ $currIcao }}</h2>
            <small class="d-block text-muted">@lang('airports.current')</small>
          </div>
        </div>
        @endif
        @if(setting('pilots.allow_transfer_hours') === true)
        <div class="col-md-6 mb-3">
          <div class="tile tile-bg-4 text-center h-100 p-3">
            <h2 class="stat-number mb-0">@minutestohours($user->transfer_time)h</h2>
            <small class="d-block text-muted">@lang('profile.transferhours')</small>
          </div>
        @endif
        
      </div>
     </div>
    
         
              
  @include('widgets.profile.avg_score', ['user' => $user, 'title' => __('Average Scores Over Time')])
  
  



      {{-- RECENT FLIGHTS (table-dva) --}}
      
      @if(isset($pireps) && $pireps->count())
      <div class="card-glass mb-3">
        <div class="header-bar">🛫 @lang('pireps.recent') / {{ trans_choice('common.pirep', 2) }}</div>
        <div class="p-0">
          <div class="table-responsive">
            <table class="table table-hover table-dva mb-0">
              <thead>
                <tr class="text-small header">
                  <th>@lang('common.flight')</th>
                  <th>@lang('common.departure')</th>
                  <th>@lang('common.arrival')</th>
                  <th class="text-center">@lang('flights.flighttime')</th>
                  <th class="text-center">@lang('common.status')</th>
                  <th>@lang('pireps.submitted')</th>
                </tr>
              </thead>
              <tbody>
              @foreach($pireps->take(6) as $p)
                @php
                  $state = $p->state;
                  $color = 'badge-info';
                  if($state === \App\Models\Enums\PirepState::PENDING)  $color = 'badge-warning';
                  if($state === \App\Models\Enums\PirepState::ACCEPTED) $color = 'badge-success';
                  if($state === \App\Models\Enums\PirepState::REJECTED) $color = 'badge-danger';
                @endphp
                <tr>
                  <td><a href="{{ route('frontend.pireps.show', [$p->id]) }}">{{ $p->ident }}</a></td>
                  <td>
                    @if($p->dpt_airport) {{ $p->dpt_airport->name }} @endif
                    ({{ $p->dpt_airport_id }})
                  </td>
                  <td>
                    @if($p->arr_airport) {{ $p->arr_airport->name }} @endif
                    ({{ $p->arr_airport_id }})
                  </td>
                  <td class="text-center">@minutestotime($p->flight_time)</td>
                  <td class="text-center"><span class="badge {{ $color }}">{{ \App\Models\Enums\PirepState::label($state) }}</span></td>
                  <td>{{ filled($p->submitted_at) ? $p->submitted_at->diffForHumans() : '' }}</td>
                </tr>
              @endforeach
              </tbody>
            </table>
          </div>
          
        </div>
      </div>
      @endif
    
        @include('widgets.profile.last30', ['user' => $user])
    
    <br>
    
    @include('widgets.profile.recent_pireps', ['user' => $user, 'limit' => 7])
    <br>

      {{-- BIO / NOTES --}}
      <div class="card-glass mb-4">
        <div class="header-bar">📝 {{ __('About the Pilot') }}</div>
        <div class="p-3">
          <div class="text-muted">
            {{ $user->bio ?? __('Professional virtual pilot profile. Keep flying sharp, safe, and smooth!') }}
          </div>
        </div>
      </div>

    </div>

    {{-- RIGHT (4) --}}
    <div class="col-lg-4">

      {{-- IDENTITY SUMMARY --}}
      <div class="card-glass mb-3">
        <div class="header-bar">👤 {{ __('Pilot Summary') }}</div>
        <div class="p-3">
          <div class="d-flex align-items-center mb-3">
            <div class="mr-3">
              @if ($user->avatar)
                <img src="{{ $user->avatar->url }}" alt="avatar"
                     style="width:72px;height:72px;border-radius:999px;object-fit:cover;border:3px solid #fff;box-shadow:0 6px 18px rgba(0,0,0,.15);">
              @else
                <img src="{{ $user->gravatar(256) }}" alt="avatar"
                     style="width:72px;height:72px;border-radius:999px;object-fit:cover;border:3px solid #fff;box-shadow:0 6px 18px rgba(0,0,0,.15);">
              @endif
            </div>
            <div>
              <div class="font-weight-bold">{{ $user->name_private }}</div>
              <div class="text-muted small">
                {{ $user->ident }}@if(filled($user->callsign)) • {{ $user->callsign }}@endif
              </div>
              @if($airline->name)
                <div class="small">{{ $airline->name }}</div>
              @endif
            </div>
          </div>

          <div class="table-responsive">
            <table class="table table-hover table-dva mb-0">
              <tbody>
                @if($rank)
                  <tr>
                    <td style="width:140px;">Rank</td>
                    <td>{{ $rank->name }}</td>
                  </tr>
                @endif
                @if($homeIcao)
                  <tr>
                    <td>@lang('airports.home')</td>
                    <td>{{ $homeIcao }}</td>
                  </tr>
                @endif
                @if($currIcao)
                  <tr>
                    <td>@lang('airports.current')</td>
                    <td>{{ $currIcao }}</td>
                  </tr>
                @endif
                <tr>
                  <td>@lang('common.timezone')</td>
                  <td>{{ $user->timezone }}</td>
                </tr>
                <tr>
                  <td>@lang('profile.opt-in')</td>
                  <td>{{ $user->opt_in ? __('common.yes') : __('common.no') }}</td>
                </tr>
                <tr>
                  <td>Discord</td>
                  <td>{{ $user->discord_id ?? '-' }}</td>
                </tr>
                <tr>
                  <td>Ratings </td>
                    <td>{{-- QUALIFICATIONS / RATINGS --}}
                      @if(!empty($user->typeRatings) || !empty($icao_codes))
                      
                              <div class="text-muted text-uppercase small mb-2">{{ __('Type Ratings') }}</div>
                              <ul class="mb-0" style="padding-left:1rem;">
                                @forelse($user->typeRatings ?? [] as $tr)
                                  <li>{{ $tr->type ?? '' }} {{ $tr->name ? '— '.$tr->name : '' }}</li>
                                @empty
                                  <li class="text-muted">—</li>
                                @endforelse
                              </ul>
                            </div>
                        </div>
                      </div>
                      @endif 
                    </td>
                </tr>
              </tbody>
            </table>
          </div>

          @if(Auth::check() && $user->id === Auth::user()->id)
            <div class="mt-3">
              <a href="{{ route('frontend.profile.regen_apikey') }}" class="btn btn-dva-warning btn-sm"
                 onclick="return confirm('Are you sure? This will reset your API key!')">@lang('profile.newapikey')</a>
            </div>
          @endif
        </div>
      </div>

      {{-- RANK BADGE --}}
      @include('widgets.profile.rank_progress', ['user' => $user, 'class' => 'col-12 col-md-12'])


      {{-- AWARDS GRID --}}
      @if ($user->awards && $user->awards->count())
      <div class="card-glass">
        <div class="header-bar">🏆 @lang('profile.your-awards')</div>
        <div class="p-3">
          <div class="row">
            @foreach($user->awards as $award)
              <div class="col-6 mb-3">
                <div class="card-glass p-2 h-100 text-center">
                  <div class="small font-weight-bold mb-1">{{ $award->name }}</div>
                  @if ($award->image_url)
                    <img src="{{ $award->image_url }}" alt="{{ $award->description }}"
                         style="max-width:72px;height:auto;filter:drop-shadow(0 6px 12px rgba(0,0,0,.18));">
                  @endif
                  <div class="text-muted small mt-1">{{ $award->description }}</div>
                </div>
              </div>
            @endforeach
          </div>
        </div>
      </div>
      @endif

    </div>
  </div>

</div>
@endsection
