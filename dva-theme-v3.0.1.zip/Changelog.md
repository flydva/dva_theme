# DVA Theme — Changelog

> **Important:** Starting with **v3.0.1**, this theme is the **only version compatible with the DisposableBasic and DisposableSpecial modules** (aka *DBasic* and *DSpecial*). Older theme versions do **not** include the required guards and integrations.

---

## [3.0.1] - 2025-10-03
### Added
- **DBasic/DSpecial integration layer**
  - Safe guards so the theme only calls widgets, routes, and helpers if the modules are present.
  - New helpers pattern:
    - `@includeIf('theme_helpers')`
    - `$DBasic = function_exists('check_module') ? check_module('DisposableBasic') : false;`
    - `$DSpecial = function_exists('check_module') ? check_module('DisposableSpecial') : false;`
    - `$units = function_exists('DT_GetUnits') ? DT_GetUnits() : ['currency' => 'USD','fuel'=>'kg','distance'=>'nm','weight'=>'kg'];`
  - Navigation items and widgets are conditionally shown to prevent **route not defined** errors when modules are missing.

- **Dashboard-grade UI refresh** across pages/components:
  - Introduced **dash-hero**, **card-glass**, **header-bar**, **tile** styles for a cohesive look.
  - Restyled pages: Awards, Hubs & Hub Details, Flights (arrivals/departures), Pilots (hub/visitor),
    Reports, Fleet (list & index), Aircraft details, NOTAMs, Market (+ personal items), News,
    Tours (list, details, map modal), Tour legs & leaderboard, Subfleet details, Operations Manual.
  - Consistent spacing, typography, and responsive tables (**table-dva**, **table-dva--blue**).

- **Fuel Calculator modal widget**
  - Fuel calculator is now presented in a compact **modal widget**; launch from a button on aircraft pages.
  - Uses `@widget('DBasic::FuelCalculator', ['aircraft' => $aircraft->id])` with a Bootstrap modal wrapper.

- **Icon/emoji semantics** for quick scanning
  - Fuel ⛽, Maintenance 🛠️, Reports 🧾, Awards 🏅, News 📰, Manual 📘, Downloads ⬇️, Shop 🛍️, Notices 📢, Airline ✈️, Hub 🏢, Fleet 🛩️, Ranks 🎖️, World 🌍, User 🧑‍✈️.

### Changed
- **Theme primary accents** shifted from orange to **dark blue**.
- Tables moved to the new **table-dva/table-dva--blue** scheme (no inline CSS, better contrast and hover states).
- Market pages re-skinned with a storefront feel (badges, pricing emphasis, gift modal polish).
- Tour tables now show validity periods, subfleet requirements, and action buttons with clearer tooltips and guards.
- Hubs & Fleet tables: columns realigned, better mobile behavior, and sticky headers within scrollable containers.

### Fixed
- **Date API misuse**: `Call to undefined method DS_Tour::endOfDay()`
  - Reworked code to only call `startOfDay()/endOfDay()` on **Carbon instances** (leg- or tour-scoped dates).

- **Null access**: `Attempt to read property "id" on null`
  - Wrapped profile links in `optional()` checks (e.g., `optional($a->user)`) and gated links if related model is missing.

- **Money rendering**: `Object of class App\Support\Money could not be converted to float`
  - Added **format_money_any()** helper to safely render all money-like objects or simple numerics.
  - Balance display updated to use `optional($user->journal)->balance` with graceful fallbacks and styling.

- **Undefined variables** (e.g., `$DSpecial` on profile and nav)
  - Centralized detection/bootstrapping in views; defaults to `false` when modules aren’t available.

- **Missing routes**: `Route [DSpecial.notams] not defined`
  - Nav and buttons are hidden unless `$DSpecial === true` and the route is available.

- **Inline styles removed** in favor of utility classes and theme CSS, for easier maintenance and dark-mode friendliness.

### Removed
- Legacy orange color tokens and isolated inline CSS rules.
- Un-guarded calls to module widgets/routes that could break when modules are not installed.

### Breaking Changes
- **v3.0.1 is the only theme version that supports DisposableBasic/DisposableSpecial**.
- Older theme versions may trigger errors if those modules are installed/enabled.
- If you extend/override the theme, update your partials to use the new guards and classes.

### Compatibility
- phpVMS v7 (current stable).
- **DisposableBasic**/**DisposableSpecial**: required for full functionality; when not present, related features are automatically hidden.
- Ensure both modules are updated to their latest releases compatible with phpVMS v7.

### Migration Notes (from 2.2.1)
1. **Publish/replace** your theme assets with v3.0.1.
2. Add the new guards to any custom/overridden blades:
   ```blade
   @includeIf('theme_helpers')
   @php
     $DBasic   = $DBasic   ?? (function_exists('check_module') ? check_module('DisposableBasic')  : false);
     $DSpecial = $DSpecial ?? (function_exists('check_module') ? check_module('DisposableSpecial') : false);
     $units    = $units    ?? (function_exists('DT_GetUnits') ? DT_GetUnits() : ['currency'=>'USD','fuel'=>'kg','distance'=>'nm','weight'=>'kg']);
   @endphp
   ```
3. Replace inline styles with the new **card-glass**, **header-bar**, **table-dva** classes.
4. Update fleet/tour blades to the dark-blue table style and Carbon-safe date usage.
5. Clear caches:
   ```bash
   php artisan view:clear
   php artisan cache:clear
   php artisan config:clear
   ```

### Known Notes
- If you use customized navigation, ensure any **DSpecial** routes are wrapped with the module guard to prevent 404/route exceptions.
- Money formatting differs between virtual airline setups; use the provided `format_money_any()` helper or your platform’s native money presenter.

---

## [2.2.1] - 2025-xx-xx
> Previous stable with the original orange accent and fewer guards.
- Basic tables/cards, limited module-aware behavior.
- Some views contained inline CSS and unguarded widget/route calls.
- Market and Tours pages used earlier component styles.
- No modal widget for Fuel Calculator.
